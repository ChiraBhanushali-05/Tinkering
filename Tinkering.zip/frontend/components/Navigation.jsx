"use client"
import React, { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import MultiDropdowns from "./Dropdown";
import { motion } from "framer-motion";
import SheetDemo from "../components/SheetDemo";
import BlurIn from "../components/magicui/blur-in";

export function ExampleNavbarThree() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [user, setUser] = useState(null); // This holds the logged-in user

  // Fetch user session status from the backend
  useEffect(() => {
    const fetchUserSession = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/session`, { credentials: 'include' });
        const data = await response.json();
        setUser(data.user || null); // Set the user if found, otherwise null
      } catch (error) {
        console.error("Error fetching user session:", error);
      }
    };

    fetchUserSession();
  }, []); // Runs once on component mount

  // Toggle menu function
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // Track screen size for responsiveness
  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 1024);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <div className="relative w-full bg-primary_color2 rounded-lg">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.15, ease: "easeOut" }}
          viewport={{ once: true }}
        >
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between px-4 py-2 sm:px-6 lg:px-8">
            <div className="flex w-full items-center justify-between">
              <div className="inline-flex items-center space-x-2">
                <BlurIn
                  word="Tinkering Hub"
                  className="font-bold text-black dark:text-white"
                ></BlurIn>
                <span className="w-40">
                  <img src="/images/logo1.png" alt="Tinkering Hub Logo" />
                </span>
              </div>

              {/* Search Input and Buttons for Large Screens */}
              <div className="flex grow justify-end mr-2 hidden lg:flex">
                <input
                  className="flex h-10 w-[180px] text-black rounded-md bg-gray-100 px-3 py-2 text-sm placeholder:text-gray-600"
                  type="text"
                  placeholder="Search"
                />
                <button className="bg-black text-white rounded-lg w-32 ml-3">
                  Search
                </button>
              </div>

              {/* Auth Button (Login/Logout) */}
              <div className="hidden lg:block">
                {user ? (
                  // Show Logout button if the user is logged in
                  <button
                    onClick={() =>
                      window.location.href = `${process.env.NEXT_PUBLIC_API_URL}/api/auth/logout`
                    }
                    className="rounded-md border border-black px-3 py-2 text-sm font-semibold text-black shadow-sm"
                  >
                    Logout
                  </button>
                ) : (
                  // Show Login with Google button if no user is logged in
                  <button
                    onClick={() =>
                      window.location.href = `${process.env.NEXT_PUBLIC_API_URL}/api/auth/google`
                    }
                    className="rounded-md bg-transparent px-3 py-2 text-sm font-semibold text-black hover:bg-black/10"
                  >
                    Login with Google
                  </button>
                )}
              </div>

              {/* Menu Button for Small Screens */}
              <div className="flex lg:hidden">
                <button
                  onClick={toggleMenu}
                  className="rounded-lg bg-black p-2 text-white hover:bg-gray-700"
                >
                  <Menu className="h-6 w-6" aria-hidden="true" />
                </button>
              </div>
            </div>

            {!isSmallScreen && <MultiDropdowns />}
          </div>
        </motion.div>
      </div>

      {/* Sheet Demo Drawer */}
      <SheetDemo isOpen={isMenuOpen} onClose={toggleMenu} />
    </>
  );
}

export default ExampleNavbarThree;
